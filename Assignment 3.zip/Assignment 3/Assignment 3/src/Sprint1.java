import java.awt.*;
import java.awt.event.*;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import javax.swing.*;

public class Sprint1 {
		
	public static void main(String[] args) {
		JFrame frame = new JFrame("Retail Outlet");
		frame.setLayout(new BorderLayout());
		JTextArea textArea = new JTextArea(500,50);
		frame.add(textArea,BorderLayout.NORTH);
		
		JMenu registerMI = new JMenu("Register");		
		JMenu loginMI = new JMenu("Login");
		JMenu exitMI = new JMenu("Exit");
		
		//Action Listeners
		registerMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//**Register Code Here
				
			}});
		loginMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//**Login Code Here	
				
			}});
		
		// create a menu bar and use it in this JFrame
		JMenuBar menuBar = new JMenuBar();
		menuBar.add(registerMI);
		menuBar.add(loginMI);
		menuBar.add(exitMI);
		frame.setJMenuBar(menuBar);
	
		// Final JFrame methods to set close operation + set size and visibility
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,550);
		frame.setVisible(true);
	    }

				

}
