import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import javax.swing.*;

public class Sprint1 {
		
	public static void main(String[] args) {
		ArrayList<User> userList = new ArrayList<User>();
		JFrame frame = new JFrame("Retail Outlet");
		frame.setLayout(new BorderLayout());
		JTextArea textArea = new JTextArea(500,50);
		frame.add(textArea,BorderLayout.NORTH);
		
		JMenu registerMI = new JMenu("Register/Login");		
		//JMenu loginMI = new JMenu("Login");
		JMenu exitMI = new JMenu("Exit");
		
		JMenuItem registerItem = new JMenuItem("Register");
		JMenuItem loginItem = new JMenuItem("Login");
		
		//Action Listeners
		registerItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				//Components for registration dialog
				JLabel regLbl = new JLabel("Register with the system");
				JLabel space = new JLabel("");
				JLabel usrLbl = new JLabel("Enter username:");
				JTextField usrTfld = new JTextField();
				JLabel pswdLbl1 = new JLabel("Enter password:");
				JPasswordField pswdFld1 = new JPasswordField();
				JLabel pswdLbl2 = new JLabel("Re-enter password:");
				JPasswordField pswdFld2 = new JPasswordField();
				JLabel emptyUsrErr = new JLabel("Enter a username.");
				JLabel takenUsrErr = new JLabel("Username already registered. Please choose a different username and try again.");
				JLabel pswdErr = new JLabel("Password fields do not match.");
				JLabel validReg = new JLabel("You have successfully registered with the system.");
				Boolean taken = false;
				
				//Registration dialog box
				int register = JOptionPane.showOptionDialog(null, new Object[] {regLbl,space,usrLbl,usrTfld,pswdLbl1,pswdFld1,pswdLbl2,pswdFld2},
				"Registration", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, null, null);
				
				//Registration logic
				if(register == JOptionPane.OK_OPTION) {
					
					for(User u: userList) {
						
						if(u.getUsername().equals(usrTfld.getText())) {

							JOptionPane.showMessageDialog(null, new Object[] {takenUsrErr}, "Username error", JOptionPane.ERROR_MESSAGE);
							taken = true;
							
						}						
					}
					
					if(!taken) {
						
						if(usrTfld.getText().equals("")) {
							
							JOptionPane.showMessageDialog(null, new Object[] {emptyUsrErr}, "Username error", JOptionPane.ERROR_MESSAGE);
							
						}
						else if(!pswdFld1.getText().equals(pswdFld2.getText())) {
							
							JOptionPane.showMessageDialog(null, new Object[] {pswdErr}, "Password error", JOptionPane.ERROR_MESSAGE);
							
						}
						else {
								
							User user = new User(usrTfld.getText(), pswdFld1.getText());
							userList.add(user);
							
							JOptionPane.showMessageDialog(null, new Object[] {validReg}, "Registration", JOptionPane.INFORMATION_MESSAGE);
							
						}						
					}				
				}
			}});
		
		loginItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			
				JLabel logLbl = new JLabel("Login to the system");
				JLabel space = new JLabel("");
				JLabel usrLbl = new JLabel("Enter username:");
				JTextField usrTfld = new JTextField();
				JLabel pswdLbl = new JLabel("Enter password:");
				JPasswordField pswdFld = new JPasswordField();
				JLabel validLog = new JLabel("You are now logged into the system.");
				JLabel logErr = new JLabel("Login error.");
				Boolean loggedIn = false;
				
				int login = JOptionPane.showOptionDialog(null, new Object[] {logLbl,space,usrLbl,usrTfld,pswdLbl,pswdFld},
						"Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, null, null);
				
				if(login == JOptionPane.OK_OPTION) {
					
					for(User u: userList) {
						
						if(u.getUsername().equals(usrTfld.getText()) && u.getPassword().equals(pswdFld.getText())) {
							
							
							loggedIn = true;
							
						}					
					}
					
					if(loggedIn) {
						
						JOptionPane.showMessageDialog(null, new Object[] {validLog}, "Login", JOptionPane.INFORMATION_MESSAGE);
						
					}
					else
						JOptionPane.showMessageDialog(null, new Object[] {logErr}, "Login error", JOptionPane.ERROR_MESSAGE);
				}
			}});
		
		registerMI.add(registerItem);
		registerMI.add(loginItem);
		
		// create a menu bar and use it in this JFrame
		JMenuBar menuBar = new JMenuBar();
		menuBar.add(registerMI);
		//menuBar.add(loginMI);
		menuBar.add(exitMI);
		frame.setJMenuBar(menuBar);
	
		// Final JFrame methods to set close operation + set size and visibility
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(500,550);
		frame.setVisible(true);
	    }

				

}